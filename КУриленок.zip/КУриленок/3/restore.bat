@echo off
set PGPASSWORD=De_05
set DB_NAME=BD
set BIN_PATH="C:\Program Files\PostgreSQL\18\bin"

echo --- Завершение активных сессий и удаление базы %DB_NAME% ---
:: Подключаемся к базе 'postgres', чтобы выполнить команду завершения сессий в 'BD'
%BIN_PATH%\psql.exe -U sa -h localhost -d postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '%DB_NAME%' AND pid <> pg_backend_pid();"

echo --- Пересоздание базы данных ---
%BIN_PATH%\dropdb.exe -U sa -h localhost --if-exists %DB_NAME%
%BIN_PATH%\createdb.exe -U sa -h localhost %DB_NAME%

echo --- Восстановление данных из бэкапа ---
%BIN_PATH%\pg_restore.exe -U sa -h localhost -d %DB_NAME% -v "C:\backups\BD_backup.bak"

pause