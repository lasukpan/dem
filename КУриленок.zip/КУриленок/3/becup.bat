@echo off
set PGPASSWORD=De_05
"C:\Program Files\PostgreSQL\18\bin\pg_dump.exe" -U sa -h localhost -F c -b -v -f "C:\backups\BD_backup.bak" BD
pause