import sys
import psycopg2
from psycopg2 import Error
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QTableWidget, QTableWidgetItem, 
                             QComboBox, QPushButton, QLineEdit, QLabel, 
                             QRadioButton, QButtonGroup, QMessageBox)
from PyQt6.QtGui import QColor

class OrderManagerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ООО Молочный комбинат 'Полесье' - Управление заказами")
        self.setMinimumSize(900, 600)
        
        # Параметры подключения к БД
        self.db_params = {
            "dbname": "your_db",
            "user": "postgres",
            "password": "password",
            "host": "localhost"
        }
        
        self.init_ui()
        self.load_customers()
        self.load_data()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # --- Блок фильтрации ---
        filter_layout = QHBoxLayout()
        self.customer_box = QComboBox()
        self.customer_box.addItem("Все клиенты")
        
        btn_filter = QPushButton("Фильтровать")
        btn_filter.clicked.connect(self.apply_filter)
        
        btn_show_all = QPushButton("Показать все")
        btn_show_all.clicked.connect(self.load_data)
        
        filter_layout.addWidget(QLabel("Клиент:"))
        filter_layout.addWidget(self.customer_box)
        filter_layout.addWidget(btn_filter)
        filter_layout.addWidget(btn_show_all)
        filter_layout.addStretch()
        
        # --- Блок поиска ---
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Введите текст для поиска...")
        btn_search = QPushButton("Найти")
        btn_search.clicked.connect(self.search_data)
        
        search_layout.addWidget(QLabel("Поиск:"))
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(btn_search)

        # --- Блок сортировки ---
        sort_layout = QHBoxLayout()
        self.sort_column = QComboBox()
        self.sort_column.addItems(["ID Заказа", "Клиент", "Дата", "Сумма"])
        
        self.sort_asc = QRadioButton("По возрастанию")
        self.sort_desc = QRadioButton("По убыванию")
        self.sort_asc.setChecked(True)
        
        self.sort_asc.toggled.connect(self.load_data)
        self.sort_desc.toggled.connect(self.load_data)
        
        sort_layout.addWidget(QLabel("Сортировать по:"))
        sort_layout.addWidget(self.sort_column)
        sort_layout.addWidget(self.sort_asc)
        sort_layout.addWidget(self.sort_desc)

        # --- Таблица ---
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID Заказа", "Клиент", "Дата", "Сумма"])

        # --- Итоги ---
        self.footer_label = QLabel("Всего заказов: 0 | Общая сумма: 0.00")
        self.footer_label.setStyleSheet("font-weight: bold; font-size: 14px; margin-top: 10px;")

        # Собираем всё вместе
        main_layout.addLayout(filter_layout)
        main_layout.addLayout(search_layout)
        main_layout.addLayout(sort_layout)
        main_layout.addWidget(self.table)
        main_layout.addWidget(self.footer_label)

    # --- ЛОГИКА РАБОТЫ С БД ---

    def execute_query(self, query, params=None):
        try:
            conn = psycopg2.connect(**self.db_params)
            cur = conn.cursor()
            cur.execute(query, params)
            data = cur.fetchall()
            cur.close()
            conn.close()
            return data
        except Error as e:
            QMessageBox.critical(self, "Ошибка БД", f"Не удалось выполнить запрос:\n{e}")
            return []

    def load_customers(self):
        data = self.execute_query("SELECT name FROM Customers ORDER BY name")
        for row in data:
            self.customer_box.addItem(row[0])

    def load_data(self, filter_client=None):
        column_map = {"ID Заказа": "o.order_id", "Клиент": "c.name", "Дата": "o.order_date", "Сумма": "o.total_amount"}
        sort_col = column_map[self.sort_column.currentText()]
        order = "ASC" if self.sort_asc.isChecked() else "DESC"
        
        query = """
            SELECT o.order_id, c.name, o.order_date, o.total_amount 
            FROM Orders o 
            JOIN Customers c ON o.customer_id = c.customer_id
        """
        params = []
        if filter_client and filter_client != "Все клиенты":
            query += " WHERE c.name = %s"
            params.append(filter_client)
            
        query += f" ORDER BY {sort_col} {order}"
        
        data = self.execute_query(query, params)
        self.update_table(data)

    def update_table(self, data):
        self.table.setRowCount(0)
        total_sum = 0
        for row_idx, row_data in enumerate(data):
            self.table.insertRow(row_idx)
            for col_idx, value in enumerate(row_data):
                item = QTableWidgetItem(str(value))
                self.table.setItem(row_idx, col_idx, item)
            total_sum += float(row_data[3]) if row_data[3] else 0
            
        self.footer_label.setText(f"Всего заказов: {len(data)} | Общая сумма: {total_sum:.2f}")

    def apply_filter(self):
        client = self.customer_box.currentText()
        self.load_data(filter_client=client)

    def search_data(self):
        text = self.search_input.text().lower()
        if not text:
            return
            
        for row in range(self.table.rowCount()):
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if text in item.text().lower():
                    item.setBackground(QColor("yellow"))
                else:
                    item.setBackground(QColor("white"))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = OrderManagerApp()
    window.show()
    sys.exit(app.exec())